<?php

namespace App\Http\Controllers;

use App\Mail\EmailSendConfirmation;
use Illuminate\Http\Request;

use Mail;


class EmailController extends Controller

{


    function index()
    {
        return view('email_send_form');
    }


    function sendmessage(Request $request)
    {
        $subject=$request->subject;
        $message= $request->message;

        $data=['subject'=> $subject, 'message'=> $message];

        $email= $request->email;
        Mail::to($email)->send( new EmailSendConfirmation($data));


        return 'Email Send Succfully';
    }
}
